window.addEventListener('load', () => {
    generateCaptcha();
});

function generateCaptcha() {
    let captchaText = '';
    const fonts = [
        "TimesNewRoman", "fantasy", "Impact", "Georgia", "Cambria",
        "Cochin", "Gill Sans", "Franklin Gothic Medium", "Haettenschweiler", "monospace"
    ];

    for (let i = 0; i < 6; i++) {
        const asciiCode = Math.floor(Math.random() * (126 - 33 + 1)) + 33;
        const char = String.fromCharCode(asciiCode);
        const font = fonts[Math.floor(Math.random() * fonts.length)];
        const size = Math.floor(Math.random() * (30 - 12 + 1)) + 12;
        const style = Math.random() < 0.5 ? 'font-style:italic;' : 'font-weight:bold;';
        captchaText += `<span style='font-family:${font}; font-size:${size}px; ${style}'>${char}</span>`;
    }

    document.getElementById('captcha').innerHTML = captchaText;
}

function clearForm() {
    document.getElementById('uname').value = "";
    document.getElementById('pwd').value = "";
    document.getElementById('ccode').value = "";
    generateCaptcha();
}

function validateCaptcha() {
    const username = document.getElementById('uname').value;
    const password = document.getElementById('pwd').value;
    const userCaptcha = document.getElementById('ccode').value;
    const generatedCaptcha = document.getElementById('captcha').innerText;

    if (!username || !password) {
        alert("Enter Username and Password");
    } else if (userCaptcha === generatedCaptcha) {
        window.location.href = "Success.html";
    } else {
        alert("Entered Captcha is wrong! Try again...");
        clearForm();
    }
}
